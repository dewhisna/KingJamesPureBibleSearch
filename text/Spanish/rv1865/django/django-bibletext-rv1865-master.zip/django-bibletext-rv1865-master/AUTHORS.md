django-bibletext was started by Richard Bolt in December 2010. It is a pluggable translation for django-bibletext.

The primary authors are:

* Richard Bolt

The Reina Valera 1865 text revised by Dr. Ángel H. de Mora, sourced from http://lookhigher.net/bibliasespanol/reinavalera1865/.